// Lab 05 - Task 5 (optional): Lock-free (Treiber) stack with compare-and-swap
// Build : dotnet build -c Release
// Run   : dotnet run --no-build -c Release                (lock-free, 4 threads)
//         dotnet run --no-build -c Release -- 8           (override thread count)
//         dotnet run --no-build -c Release -- 4 --mutex   (same test on a lock-based stack)
using System.Diagnostics;

interface IStack
{
    void Push(int value);
    bool TryPop(out int value);
    bool IsEmpty { get; }
}

// ---------------- lock-free stack ----------------
class LockFreeStack : IStack
{
    private sealed class Node
    {
        public readonly int Value;
        public Node? Next;
        public Node(int value) => Value = value;
    }

    private Node? head;                              // top of the stack

    public void Push(int value)
    {
        var node = new Node(value);
        Node? oldHead;
        do
        {
            oldHead = Volatile.Read(ref head);       // 1. read the current top
            node.Next = oldHead;                     // 2. link the new node on top of it
        }
        // 3. swing head to node only if nobody changed it in the meantime; otherwise retry
        while (Interlocked.CompareExchange(ref head, node, oldHead) != oldHead);
    }

    public bool TryPop(out int value)
    {
        Node? oldHead;
        do
        {
            oldHead = Volatile.Read(ref head);       // 1. read the current top
            if (oldHead == null) { value = 0; return false; }   // empty stack
            // 2. try to replace the top by its successor; retry if head moved
        }
        while (Interlocked.CompareExchange(ref head, oldHead.Next, oldHead) != oldHead);

        value = oldHead.Value;
        return true;
    }

    public bool IsEmpty => Volatile.Read(ref head) == null;
}

// ---------------- mutex-protected stack (for the comparison) ----------------
class LockedStack : IStack
{
    private readonly Stack<int> items = new();
    private readonly object gate = new();
    public void Push(int value) { lock (gate) items.Push(value); }
    public bool TryPop(out int value) { lock (gate) return items.TryPop(out value); }
    public bool IsEmpty { get { lock (gate) return items.Count == 0; } }
}

class Program
{
    static int NumThreads = 4;
    const int OpsPerThread = 500_000;   // pushes (and pops) per thread

    static void Main(string[] args)
    {
        foreach (var a in args) if (int.TryParse(a, out int n) && n > 0) NumThreads = n;
        bool useMutex = args.Contains("--mutex");
        IStack stack = useMutex ? new LockedStack() : new LockFreeStack();

        int total = NumThreads * OpsPerThread;
        var popped = new int[NumThreads][];

        Console.WriteLine($"Task 5 - {(useMutex ? "LockedStack (mutex)" : "LockFreeStack (CAS)")} | ProcessorCount = {Environment.ProcessorCount}");
        Console.WriteLine($"Threads = {NumThreads}, pushes per thread = {OpsPerThread:N0}, total nodes = {total:N0}");

        var threads = new Thread[NumThreads];
        using var start = new ManualResetEventSlim(false);
        for (int t = 0; t < NumThreads; t++)
        {
            int id = t;
            popped[id] = new int[OpsPerThread];
            threads[t] = new Thread(() =>
            {
                start.Wait();                            // all threads start together
                int baseValue = id * OpsPerThread;       // each thread pushes unique values
                for (int i = 0; i < OpsPerThread; i++)
                {
                    stack.Push(baseValue + i);
                    int v;
                    while (!stack.TryPop(out v)) Thread.SpinWait(1);
                    popped[id][i] = v;                   // record what this thread removed
                }
            });
            threads[t].Start();
        }

        var sw = Stopwatch.StartNew();
        start.Set();
        foreach (var th in threads) th.Join();
        sw.Stop();

        // verification: every pushed value must be popped exactly once
        var seen = new int[total];
        foreach (var arr in popped) foreach (int v in arr) seen[v]++;
        int lost = 0, duplicated = 0;
        for (int i = 0; i < total; i++)
        {
            if (seen[i] == 0) lost++;
            else if (seen[i] > 1) duplicated += seen[i] - 1;
        }
        bool empty = stack.IsEmpty;

        Console.WriteLine($"Nodes (total) : {total:N0}");
        Console.WriteLine($"Lost          : {lost}");
        Console.WriteLine($"Duplicated    : {duplicated}");
        Console.WriteLine($"Stack empty   : {(empty ? "YES" : "NO")}");
        Console.WriteLine($"Time          : {sw.ElapsedMilliseconds} ms");
        Console.WriteLine(lost == 0 && duplicated == 0 && empty ? "RESULT: PASS" : "RESULT: FAIL");
    }
}
