// Lab 05 - Task 3: Condition-variable signaling with Monitor.Wait / Monitor.PulseAll
// Build : dotnet build -c Release
// Scenarios (dotnet run --no-build -c Release -- <arguments>):
//   A : cond                  one worker waits on the condition
//   B : cond 1 signal-first   data is published before the worker starts
//   C : cond 3                three workers wait, PulseAll wakes all of them
//   D : spin                  one worker busy-waits (polling) on the flag
// Experiments:
//   cond 1 no-pulse           lost-signal experiment (flag set, Pulse removed)
//   cond 3 pulse-one          Monitor.Pulse instead of PulseAll with 3 workers
using System.Diagnostics;

class Program
{
    const int ProducerDelayMs = 1000;            // how long the workers have to wait
    const int PublishedValue = 42;

    // ---- shared state (protected by gate) ----
    static readonly object gate = new object();
    static bool dataReady = false;               // the predicate
    static int sharedValue = 0;

    // ---- per-worker results ----
    static int[] timesBlocked = Array.Empty<int>();
    static int[] valueReceived = Array.Empty<int>();
    static long[] spinIterations = Array.Empty<long>();

    static string mode = "cond";
    static bool noPulse = false;
    static bool pulseOne = false;

    // ---------------- condition-variable worker ----------------
    static void Worker(int id)
    {
        lock (gate)
        {
            // re-check the predicate after every wake-up
            while (!dataReady)
            {
                timesBlocked[id]++;
                Monitor.Wait(gate);              // releases gate, sleeps, re-acquires gate
            }
            valueReceived[id] = sharedValue;     // predicate true AND lock held
        }
    }

    // ---------------- polling worker (scenario D) ----------------
    static void SpinWorker(int id)
    {
        while (!Volatile.Read(ref dataReady))    // busy-wait: burns a core
            spinIterations[id]++;
        valueReceived[id] = Volatile.Read(ref sharedValue);
    }

    // ---------------- publisher ----------------
    static void Publish()
    {
        lock (gate)
        {
            sharedValue = PublishedValue;
            Volatile.Write(ref dataReady, true); // set the predicate ...
            if (noPulse) { /* lost-signal experiment: no wake-up call */ }
            else if (pulseOne) Monitor.Pulse(gate);      // wakes ONE waiter only
            else Monitor.PulseAll(gate);                 // ... and wake every waiter
        }
    }

    static void Main(string[] args)
    {
        mode = args.Length > 0 ? args[0] : "cond";
        int workers = args.Length > 1 && int.TryParse(args[1], out int w) ? w : 1;
        bool signalFirst = args.Contains("signal-first");
        noPulse = args.Contains("no-pulse");
        pulseOne = args.Contains("pulse-one");

        timesBlocked = new int[workers];
        valueReceived = new int[workers];
        spinIterations = new long[workers];

        Console.WriteLine($"Task 3 - CondSignal | ProcessorCount = {Environment.ProcessorCount}");
        Console.WriteLine($"Mode = {mode}, workers = {workers}" +
                          (signalFirst ? ", signal-first" : "") +
                          (noPulse ? ", NO PULSE (lost-signal experiment)" : "") +
                          (pulseOne ? ", Pulse (one) instead of PulseAll" : ""));

        var proc = Process.GetCurrentProcess();
        var sw = Stopwatch.StartNew();

        if (signalFirst) Publish();              // scenario B: flag is already set

        var threads = new Thread[workers];
        for (int i = 0; i < workers; i++)
        {
            int id = i;
            threads[i] = mode == "spin" ? new Thread(() => SpinWorker(id)) : new Thread(() => Worker(id));
            threads[i].IsBackground = true;
            threads[i].Start();
        }

        if (!signalFirst)
        {
            Thread.Sleep(ProducerDelayMs);       // "produce" the data
            Publish();
        }

        // wait for the workers, but give up after 3 s (lost signal / missed wake-up)
        long deadline = sw.ElapsedMilliseconds + 3000;
        bool allFinished = true;
        foreach (var t in threads)
            allFinished &= t.Join((int)Math.Max(0, deadline - sw.ElapsedMilliseconds));
        sw.Stop();
        proc.Refresh();
        // whole-process CPU time (includes the small .NET start-up cost)
        double cpuMs = proc.TotalProcessorTime.TotalMilliseconds;

        for (int i = 0; i < workers; i++)
        {
            string extra = mode == "spin" ? $", spin iterations = {spinIterations[i]:N0}" : "";
            string state = threads[i].IsAlive ? "STILL WAITING (never woken)" : "finished";
            Console.WriteLine($"Worker {i}: blocked {timesBlocked[i]} time(s), value = {valueReceived[i]}{extra}, {state}");
        }
        Console.WriteLine($"Wall time : {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"CPU time  : {cpuMs:F0} ms");
        Console.WriteLine(allFinished ? "RESULT: all workers received the value"
                                      : "RESULT: some workers were never woken - stopped after timeout");
    }
}
