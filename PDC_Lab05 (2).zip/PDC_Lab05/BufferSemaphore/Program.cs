// Lab 05 - Task 2: Multiple producers / consumers with counting semaphores
// Build : dotnet build -c Release
// Run   : dotnet run --no-build -c Release -- <producers> <consumers> <capacity>
//         e.g. dotnet run --no-build -c Release -- 2 2 8
// Deadlock experiment (wrong order: lock BEFORE fullSlots.Wait in the consumer):
//         dotnet run --no-build -c Release -- 1 1 8 --deadlock
using System.Diagnostics;

class Program
{
    const int TotalItems = 1_000_000;            // items shared out among all producers

    // ---- shared buffer (protected by gate) ----
    static int[] buffer = Array.Empty<int>();
    static int inPos = 0;
    static int outPos = 0;
    static readonly object gate = new object();

    // ---- semaphores ----
    static SemaphoreSlim emptySlots = null!;     // free slots   (starts at capacity)
    static SemaphoreSlim fullSlots = null!;      // filled slots (starts at 0)

    // ---- verification ----
    static int[] seen = Array.Empty<int>();      // seen[item] = how many times item was consumed
    static long consumedTotal = 0;               // progress counter (for the deadlock watchdog)
    static bool wrongOrder = false;

    static void Producer(int firstItem, int itemCount)
    {
        for (int k = 0; k < itemCount; k++)
        {
            int item = firstItem + k;
            emptySlots.Wait();                   // 1. wait for a free slot
            lock (gate)                          // 2. exclusive access to the indices
            {
                buffer[inPos] = item;            // 3. insert and advance
                inPos = (inPos + 1) % buffer.Length;
            }                                    // 4. leave the lock
            fullSlots.Release();                 // 5. announce one more filled slot
        }
    }

    static void Consumer(int itemCount)
    {
        for (int k = 0; k < itemCount; k++)
        {
            int item;
            if (!wrongOrder)
            {
                fullSlots.Wait();                // 1. wait for a filled slot
                lock (gate)                      // 2. exclusive access
                {
                    item = buffer[outPos];       // 3. remove and advance
                    outPos = (outPos + 1) % buffer.Length;
                }                                // 4. leave the lock
                emptySlots.Release();            // 5. announce one more free slot
            }
            else
            {
                // DEADLOCK EXPERIMENT - lock taken before waiting on the semaphore
                lock (gate)
                {
                    fullSlots.Wait();            // blocks while holding gate
                    item = buffer[outPos];
                    outPos = (outPos + 1) % buffer.Length;
                }
                emptySlots.Release();
            }

            Interlocked.Increment(ref seen[item]);
            Interlocked.Increment(ref consumedTotal);
        }
    }

    static void Main(string[] args)
    {
        int producers = args.Length > 0 ? int.Parse(args[0]) : 1;
        int consumers = args.Length > 1 ? int.Parse(args[1]) : 1;
        int capacity  = args.Length > 2 ? int.Parse(args[2]) : 8;
        wrongOrder = args.Contains("--deadlock");

        buffer = new int[capacity];
        seen = new int[TotalItems];
        emptySlots = new SemaphoreSlim(capacity, capacity);
        fullSlots = new SemaphoreSlim(0, capacity);

        Console.WriteLine($"Task 2 - BufferSemaphore | ProcessorCount = {Environment.ProcessorCount}");
        Console.WriteLine($"Producers = {producers}, consumers = {consumers}, capacity = {capacity}, items = {TotalItems:N0}"
                          + (wrongOrder ? "  [DEADLOCK EXPERIMENT]" : ""));

        var threads = new List<Thread>();
        // split the items: producer p produces a contiguous, disjoint range
        int perProducer = TotalItems / producers, next = 0;
        for (int p = 0; p < producers; p++)
        {
            int first = next;
            int n = (p == producers - 1) ? TotalItems - next : perProducer;
            next += n;
            threads.Add(new Thread(() => Producer(first, n)) { Name = $"P{p}" });
        }
        // split the consumption quota the same way
        int perConsumer = TotalItems / consumers;
        for (int c = 0; c < consumers; c++)
        {
            int n = (c == consumers - 1) ? TotalItems - perConsumer * (consumers - 1) : perConsumer;
            threads.Add(new Thread(() => Consumer(n)) { Name = $"C{c}" });
        }
        foreach (var t in threads) t.IsBackground = true;   // lets the watchdog exit a deadlocked run

        var sw = Stopwatch.StartNew();
        foreach (var t in threads) t.Start();

        // watchdog: report if no progress is made for 3 seconds (deadlock)
        long last = -1;
        foreach (var t in threads)
        {
            while (!t.Join(3000))
            {
                long now = Interlocked.Read(ref consumedTotal);
                if (now == last)
                {
                    Console.WriteLine($"NO PROGRESS for 3 s after {now:N0} items consumed -> program is deadlocked. Stopping.");
                    Environment.Exit(1);
                }
                last = now;
            }
        }
        sw.Stop();

        int lost = 0, duplicated = 0;
        for (int i = 0; i < TotalItems; i++)
        {
            if (seen[i] == 0) lost++;
            else if (seen[i] > 1) duplicated += seen[i] - 1;
        }

        Console.WriteLine($"Consumed   : {consumedTotal:N0}");
        Console.WriteLine($"Lost       : {lost}");
        Console.WriteLine($"Duplicated : {duplicated}");
        Console.WriteLine($"Time       : {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"CPU time   : {Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds:F0} ms (whole process)");
        Console.WriteLine(lost == 0 && duplicated == 0 ? "RESULT: PASS" : "RESULT: FAIL");
    }
}
