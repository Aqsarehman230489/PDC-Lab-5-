// Lab 05 - Task 1: Mutex-protected bounded buffer (single producer, single consumer)
// Build : dotnet build -c Release
// Run   : dotnet run --no-build -c Release            (buffer size 8)
//         dotnet run --no-build -c Release -- 1       (optional: override buffer size)
using System.Diagnostics;

class Program
{
    // ---- configuration ----
    static int BufferSize = 8;               // change to 1 / 64 for the buffer-size experiment
    const int NumItems = 1_000_000;          // items produced and consumed

    // ---- shared state (protected by gate) ----
    static int[] buffer = Array.Empty<int>();
    static int inPos = 0;                    // next slot the producer writes
    static int outPos = 0;                   // next slot the consumer reads
    static int count = 0;                    // number of items currently in the buffer
    static readonly object gate = new object();

    // ---- statistics (each written by one thread only) ----
    static long producerRetries = 0;
    static long consumerRetries = 0;
    static long checksum = 0;
    static long orderErrors = 0;
    static long itemsReceived = 0;

    static void Producer()
    {
        for (int item = 1; item <= NumItems; item++)
        {
            while (true)
            {
                lock (gate)
                {
                    // test AND insert inside the same critical section
                    if (count < BufferSize)
                    {
                        buffer[inPos] = item;
                        inPos = (inPos + 1) % BufferSize;
                        count++;
                        break;                       // item inserted -> next item
                    }
                }
                // buffer full: lock already released, give the consumer a chance
                producerRetries++;
                Thread.Yield();
            }
        }
    }

    static void Consumer()
    {
        for (int expected = 1; expected <= NumItems; expected++)
        {
            int item;
            while (true)
            {
                lock (gate)
                {
                    if (count > 0)
                    {
                        item = buffer[outPos];
                        outPos = (outPos + 1) % BufferSize;
                        count--;
                        break;                       // item removed
                    }
                }
                // buffer empty: retry later
                consumerRetries++;
                Thread.Yield();
            }

            // verification (outside the lock - only the consumer touches these)
            checksum += item;
            itemsReceived++;
            if (item != expected) orderErrors++;
        }
    }

    static void Main(string[] args)
    {
        if (args.Length > 0 && int.TryParse(args[0], out int size) && size > 0)
            BufferSize = size;

        buffer = new int[BufferSize];
        long expectedChecksum = (long)NumItems * (NumItems + 1) / 2;

        Console.WriteLine($"Task 1 - BufferMutex | ProcessorCount = {Environment.ProcessorCount}");
        Console.WriteLine($"Buffer size = {BufferSize}, items = {NumItems:N0}");

        var sw = Stopwatch.StartNew();
        var producer = new Thread(Producer) { Name = "Producer" };
        var consumer = new Thread(Consumer) { Name = "Consumer" };
        producer.Start();
        consumer.Start();
        producer.Join();
        consumer.Join();
        sw.Stop();

        bool checksumOk = checksum == expectedChecksum;
        Console.WriteLine($"Items received   : {itemsReceived:N0}");
        Console.WriteLine($"Checksum         : {checksum} (expected {expectedChecksum}) -> {(checksumOk ? "OK" : "MISMATCH")}");
        Console.WriteLine($"Order errors     : {orderErrors}");
        Console.WriteLine($"Producer retries : {producerRetries:N0}");
        Console.WriteLine($"Consumer retries : {consumerRetries:N0}");
        Console.WriteLine($"Time             : {sw.ElapsedMilliseconds} ms");
        Console.WriteLine($"CPU time         : {Process.GetCurrentProcess().TotalProcessorTime.TotalMilliseconds:F0} ms (whole process)");
        Console.WriteLine(checksumOk && orderErrors == 0 && count == 0 ? "RESULT: PASS" : "RESULT: FAIL");
    }
}
