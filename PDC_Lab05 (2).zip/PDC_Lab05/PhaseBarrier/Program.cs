// Lab 05 - Task 4: Reusable phase barrier for round-based worker threads
// Build : dotnet build -c Release
// Run   : dotnet run --no-build -c Release                    (4 workers, with barrier)
//         dotnet run --no-build -c Release -- --no-barrier     (experiment: barrier removed)
//         dotnet run --no-build -c Release -- 8                (8 workers)
//
// Computation: a 1-D stencil. Every round each cell becomes a function of itself and
// its two neighbours from the PREVIOUS round. Each worker owns a contiguous block of
// cells, so block edges depend on the neighbouring worker's results.
using System.Diagnostics;

// ---------------- hand-built reusable barrier ----------------
class PhaseBarrier
{
    private readonly object gate = new object();
    private readonly int parties;        // number of threads that must arrive
    private int waiting = 0;             // threads arrived in the current generation
    private long generation = 0;         // incremented every time the barrier opens

    public PhaseBarrier(int parties) => this.parties = parties;

    public void SignalAndWait()
    {
        lock (gate)
        {
            long myGeneration = generation;
            waiting++;
            if (waiting == parties)
            {
                // last thread to arrive: reset for the next use and release everybody
                waiting = 0;
                generation++;
                Monitor.PulseAll(gate);
            }
            else
            {
                // wait until THIS generation has been released
                // (loop guards against spurious wake-ups; generation check makes it reusable)
                while (myGeneration == generation)
                    Monitor.Wait(gate);
            }
        }
    }
}

class Program
{
    const int Cells = 200_000;
    const int Rounds = 500;
    const int Modulus = 1_000_003;

    static int[] current = Array.Empty<int>();
    static int[] next = Array.Empty<int>();

    static int Step(int[] a, int i)
    {
        // fixed boundaries: cell 0 and cell Cells-1 never change
        if (i == 0 || i == Cells - 1) return a[i];
        return (int)(((long)a[i - 1] + 2L * a[i] + 3L * a[i + 1] + i) % Modulus);
    }

    static int[] Initial()
    {
        var a = new int[Cells];
        for (int i = 0; i < Cells; i++) a[i] = (int)((i * 7919L) % Modulus);
        return a;
    }

    static int[] SequentialReference()
    {
        int[] cur = Initial(), nxt = new int[Cells];
        for (int r = 0; r < Rounds; r++)
        {
            for (int i = 0; i < Cells; i++) nxt[i] = Step(cur, i);
            (cur, nxt) = (nxt, cur);
        }
        return cur;
    }

    static void Worker(int id, int workers, PhaseBarrier? barrier)
    {
        int chunk = Cells / workers;
        int start = id * chunk;
        int end = (id == workers - 1) ? Cells : start + chunk;

        for (int r = 0; r < Rounds; r++)
        {
            // phase 1: compute the new values from the old array
            for (int i = start; i < end; i++) next[i] = Step(current, i);

            barrier?.SignalAndWait();     // barrier 1: every 'next' value is written

            // phase 2: copy the new values back (current <- next) for my block
            for (int i = start; i < end; i++) current[i] = next[i];

            barrier?.SignalAndWait();     // barrier 2: every 'current' value is updated
        }
    }

    static void Main(string[] args)
    {
        int workers = 4;
        foreach (var a in args) if (int.TryParse(a, out int w) && w > 0) workers = w;
        bool useBarrier = !args.Contains("--no-barrier");

        Console.WriteLine($"Task 4 - PhaseBarrier | ProcessorCount = {Environment.ProcessorCount}");
        Console.WriteLine($"Workers = {workers}, cells = {Cells:N0}, rounds = {Rounds}, barrier = {(useBarrier ? "ON" : "OFF")}");

        int[] reference = SequentialReference();

        current = Initial();
        next = new int[Cells];
        var barrier = useBarrier ? new PhaseBarrier(workers) : null;

        var threads = new Thread[workers];
        var sw = Stopwatch.StartNew();
        for (int i = 0; i < workers; i++)
        {
            int id = i;
            threads[i] = new Thread(() => Worker(id, workers, barrier));
            threads[i].Start();
        }
        foreach (var t in threads) t.Join();
        sw.Stop();

        int mismatches = 0;
        for (int i = 0; i < Cells; i++) if (current[i] != reference[i]) mismatches++;

        Console.WriteLine($"Mismatching cells : {mismatches:N0} of {Cells:N0}");
        Console.WriteLine($"Matches reference : {(mismatches == 0 ? "YES" : "NO")}");
        Console.WriteLine($"Time (parallel)   : {sw.ElapsedMilliseconds} ms");
    }
}
