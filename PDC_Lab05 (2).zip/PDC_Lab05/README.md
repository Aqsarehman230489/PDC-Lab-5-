# PDC Lab 05 - Synchronization Mechanisms (C#)

Open the folder in VS Code (or open PDC_Lab05.sln). For each project:

    cd <Project>
    dotnet build -c Release
    dotnet run --no-build -c Release [-- args]

| Project | Runs |
|---|---|
| BufferMutex | (none) = size 8; `-- 1`, `-- 64` for buffer-size experiment |
| BufferSemaphore | `-- 1 1 8`, `-- 2 2 8`, `-- 4 4 8`, `-- 4 4 1`, `-- 4 4 64`, `-- 4 2 8`; deadlock: `-- 1 1 8 --deadlock` |
| CondSignal | A `-- cond`, B `-- cond 1 signal-first`, C `-- cond 3`, D `-- spin`; lost signal: `-- cond 1 no-pulse`; `-- cond 3 pulse-one` |
| PhaseBarrier | (none) = 4 workers; `-- --no-barrier`; `-- 8` |
| LockFreeStack | (none) = 4 threads; `-- 8`; `-- 4 --mutex`, `-- 8 --mutex` |

PowerShell, 5 runs: `1..5 | ForEach-Object { dotnet run --no-build -c Release }`

Targets net8.0 with RollForward=Major, so it also runs if only .NET 9/10 is installed.
raw_console_output.txt has the full output of every run used in the report.
